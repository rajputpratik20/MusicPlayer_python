import os
import tkinter as tk
from tkinter import filedialog
import pygame

class MusicPlayer:
    def __init__(self, root):
        self.root = root
        self.root.title("Music Player")
        self.root.geometry("500x300")

        pygame.init()
        pygame.mixer.init()

        self.playlist = []
        self.current_song_index = 0
        self.volume = 0.5

        self.create_widgets()

    def create_widgets(self):
        self.playlist_box = tk.Listbox(self.root, selectmode=tk.SINGLE, bg="lightgrey", selectbackground="orange")
        self.playlist_box.pack(fill=tk.BOTH, expand=True)

        self.btn_add = tk.Button(self.root, text="Add Song", command=self.add_song)
        self.btn_add.pack()

        self.btn_remove = tk.Button(self.root, text="Remove Song", command=self.remove_song)
        self.btn_remove.pack()

        self.btn_play = tk.Button(self.root, text="Play", command=self.play_song)
        self.btn_play.pack(side=tk.LEFT)

        self.btn_pause = tk.Button(self.root, text="Pause", command=self.pause_song)
        self.btn_pause.pack(side=tk.LEFT)

        self.btn_stop = tk.Button(self.root, text="Stop", command=self.stop_song)
        self.btn_stop.pack(side=tk.LEFT)

        self.btn_prev = tk.Button(self.root, text="Previous", command=self.play_previous)
        self.btn_prev.pack(side=tk.LEFT)

        self.btn_next = tk.Button(self.root, text="Next", command=self.play_next)
        self.btn_next.pack(side=tk.LEFT)

        self.volume_slider = tk.Scale(self.root, from_=0, to=1, resolution=0.1, orient=tk.HORIZONTAL,
                                      label="Volume", command=self.set_volume)
        self.volume_slider.set(self.volume)
        self.volume_slider.pack(fill=tk.X)

    def add_song(self):
        file_paths = filedialog.askopenfilenames(filetypes=[("MP3 files", "*.mp3")])
        if file_paths:
            for file_path in file_paths:
                self.playlist.append(file_path)
                song_name = os.path.basename(file_path)
                self.playlist_box.insert(tk.END, song_name)

    def remove_song(self):
        selected_index = self.playlist_box.curselection()
        if selected_index:
            index = selected_index[0]
            del self.playlist[index]
            self.playlist_box.delete(index)

    def play_song(self):
        if not pygame.mixer.music.get_busy():
            if self.playlist:
                current_song = self.playlist[self.current_song_index]
                pygame.mixer.music.load(current_song)
                pygame.mixer.music.set_volume(self.volume)
                pygame.mixer.music.play()

    def pause_song(self):
        if pygame.mixer.music.get_busy():
            if pygame.mixer.music.get_busy():
                pygame.mixer.music.pause()

    def stop_song(self):
        if pygame.mixer.music.get_busy():
            pygame.mixer.music.stop()

    def play_previous(self):
        if not pygame.mixer.music.get_busy():
            if self.playlist:
                self.current_song_index = (self.current_song_index - 1) % len(self.playlist)
                self.play_song()

    def play_next(self):
        if not pygame.mixer.music.get_busy():
            if self.playlist:
                self.current_song_index = (self.current_song_index + 1) % len(self.playlist)
                self.play_song()

    def set_volume(self, value):
        self.volume = float(value)
        pygame.mixer.music.set_volume(self.volume)

if __name__ == "__main__":
    root = tk.Tk()
    music_player = MusicPlayer(root)
    root.mainloop()
